#!/usr/bin/env bash
cd /autograder/source
# compile submissions
-o xx
